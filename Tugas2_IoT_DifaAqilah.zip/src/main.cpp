#include <Arduino.h>

int tombol1 = 34;
int tombol2 = 35;
int tombol3 = 32;

int red = 23;
int yellow = 22;
int green = 21;

void setup() {
  Serial.begin(115200);
  Serial.println("Hello, ESP 32!");
  
  pinMode(tombol1, INPUT_PULLUP);
  pinMode(tombol2, INPUT_PULLUP);
  pinMode(tombol3, INPUT_PULLUP);
  
  pinMode(red, OUTPUT);
  pinMode(yellow, OUTPUT);
  pinMode(green, OUTPUT);
}

void loop() {
  // Tombol 1: Lampu merah berkedip 5x
  if (digitalRead(tombol1) == LOW) {
    for (int i = 0; i < 5; i++) {
      digitalWrite(red, HIGH);
      delay(200);
      digitalWrite(red, LOW);
      delay(200);
    }
  }

  // Tombol 2: Lampu merah dan hijau kedip bergantian
  if (digitalRead(tombol2) == LOW) {
    digitalWrite(red, HIGH);
    digitalWrite(green, LOW);
    delay(500);
    digitalWrite(red, LOW);
    digitalWrite(green, HIGH);
    delay(500);
  }

  // Tombol 3: Lampu merah, kuning, hijau kedip bergantian
  if (digitalRead(tombol3) == LOW) {
    digitalWrite(red, HIGH);
    digitalWrite(yellow, LOW);
    digitalWrite(green, LOW);
    delay(500);
    digitalWrite(red, LOW);
    digitalWrite(yellow, HIGH);
    digitalWrite(green, LOW);
    delay(500);
    digitalWrite(red, LOW);
    digitalWrite(yellow, LOW);
    digitalWrite(green, HIGH);
    delay(500);
  }

  // Matikan semua lampu jika tidak ada tombol yang ditekan
  if (digitalRead(tombol1) == HIGH && digitalRead(tombol2) == HIGH && digitalRead(tombol3) == HIGH) {
    digitalWrite(red, LOW);
    digitalWrite(yellow, LOW);
    digitalWrite(green, LOW);
  }
}