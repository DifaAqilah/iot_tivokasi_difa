#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>

// Pin Sensor sesuai JSON
#define DHTPIN 27       // Pin data DHT22
#define LDR_AO 34       // Pin Analog LDR (AO)
#define DHTTYPE DHT22   // Jenis sensor DHT22

// Inisialisasi OLED
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET    -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// Inisialisasi DHT22
DHT dht(DHTPIN, DHTTYPE);

void setup() {
    Serial.begin(115200);

    // Inisialisasi OLED
    if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { 
        Serial.println(F("SSD1306 allocation failed"));
        while (1);
    }
    
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(WHITE);

    // Inisialisasi DHT22
    dht.begin();
}

void loop() {
    // Baca sensor
    float suhu = dht.readTemperature();
    float kelembaban = dht.readHumidity();
    int cahayaAnalog = analogRead(LDR_AO);   // Baca nilai analog LDR (A0)

    // Konversi nilai analog LDR (0-4095) ke persen (0-100%)
    float cahayaPersen = (cahayaAnalog / 4095.0) * 100.0;

    // Cek apakah pembacaan sensor gagal
    if (isnan(suhu) || isnan(kelembaban)) {
        Serial.println("Gagal membaca dari sensor DHT!");
        return;
    }

    //  Format Serial Monitor sesuai JSON (berbaris)
    Serial.println("Data Sensor ESP32:");
    Serial.print("Suhu: "); Serial.print(suhu); Serial.println(" C");
    Serial.print("Kelembaban: "); Serial.print(kelembaban); Serial.println(" %");
    Serial.print("Cahaya: "); Serial.print(cahayaPersen); Serial.println(" %");
    Serial.println("----------------------"); // Pembatas

    //  OLED
    display.clearDisplay();
    
    display.setCursor(0, 0);
    display.print("Suhu: "); display.print(suhu); display.println(" C");

    display.setCursor(0, 16);
    display.print("Kelembaban: "); display.print(kelembaban); display.println("%");

    display.setCursor(0, 32);
    display.print("Cahaya: "); display.print(cahayaPersen); display.println("%");

    // Menampilkan grafik batang cahaya
    int barLength = map(cahayaAnalog, 0, 4095, 0, 100); // Ubah nilai LDR ke skala 0-100
    display.fillRect(0, 48, barLength, 8, WHITE); // Bar semakin panjang saat cahaya terang
    
    display.display();
    
    delay(2000);
}